package com.example;

// erwartungskonform ist Variante 2 um rund Faktor 5-10 schneller
public class BooleanPoolingOptimizationBase {

	public static void main(String[] args) {

		final Boolean[] testArray = new Boolean[10_000_000];

		long start1 = System.nanoTime();
		newlyCreatedBooleans(testArray);
		long end1 = System.nanoTime();
		System.out.println("Measure 1 took: " + (end1 - start1) + "ns");

		long start2 = System.nanoTime();
		populateWithPooledValue(testArray);
		long end2 = System.nanoTime();
		System.out.println("Measure 2 took: " + (end2 - start2) + "ns");
	}

	public static void newlyCreatedBooleans(Boolean[] testArray) {
		for (int i = 0; i < testArray.length; i++) {
			testArray[i] = new Boolean(true);
		}
	}

	public static void populateWithPooledValue(Boolean[] testArray) {
		for (int i = 0; i < testArray.length; i++) {
			testArray[i] = Boolean.TRUE;
		}
	}
}
