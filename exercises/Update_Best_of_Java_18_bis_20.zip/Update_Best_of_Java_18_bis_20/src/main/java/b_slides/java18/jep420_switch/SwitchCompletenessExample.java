package b_slides.java18.jep420_switch;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class SwitchCompletenessExample
{
    // Demo: abstract wegnehmen
    static sealed abstract class BaseOp permits Add, Sub {
    }

    static final class Add extends BaseOp {
    }

    static final class Sub extends BaseOp {
    }

    static void performAction(BaseOp op) {
        switch (op) {
            case Add a -> System.out.println(a);
            case Sub s -> System.out.println(s);
            // default -> System.out.println("FALLBACK");
        }
    }

    static abstract sealed class BooleanExpression permits XORExpression, EqualsExpression
    {
        public void check(BooleanExpression bexp)
        {
            switch (bexp)
            {
                case XORExpression x -> System.out.println("XORExpression");
                case EqualsExpression e -> System.out.println("EqualsExpression");
            }
        }
    }

    static final class XORExpression extends BooleanExpression
    {
    }

    static final class EqualsExpression extends BooleanExpression
    {
    }

    public static void main(final String[] args)
    {
        final BooleanExpression base = new EqualsExpression();
        base.check(new EqualsExpression());
        base.check(new XORExpression());
    }
}

