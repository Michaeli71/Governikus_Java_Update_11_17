package b_slides.java19.jep405_record_patterns;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class Jep405_DrivingLicense {

	record Person(String name, int age, Boolean hasDrivingLicense) {
	    boolean isAllowedToDrive() {
	        return age >= 18 && hasDrivingLicense;
	    }
	}
	
	boolean isAllowedToDrive(Object obj) {
	    if (obj instanceof Person(String name, int age,
	                              Boolean hasDrivingLicense)) {
	        return age >= 18 && hasDrivingLicense;
	    }
	    return false;
	}
}
