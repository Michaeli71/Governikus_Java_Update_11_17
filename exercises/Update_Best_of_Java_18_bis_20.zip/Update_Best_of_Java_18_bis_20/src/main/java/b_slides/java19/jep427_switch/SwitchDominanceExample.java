package b_slides.java19.jep427_switch;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class SwitchDominanceExample {
    public static void main(String[] args) {

        Integer value = 4711;
        switch (value) {
            case -1, 0, 1 -> System.out.println("Handle special cases -1, 0 or 1");
            case Integer i when i > 1 -> System.out.println("Handle positive integer cases i > 1");
            case Integer i -> System.out.println("Handle all the remaining integers");
        }
    }


    static void dominanceExample(Object obj) {
        switch (obj) {
            case null -> System.out.println("null");
            case String str when str.length() > 5 -> System.out.println(str.strip());
            case String str -> System.out.println(str.toLowerCase());
            case Integer i -> System.out.println(i * i);
            default -> {
            }
        }
    }

    static void dominanceExampleWithConstant(Object obj) {
        switch (obj.toString()) {
            case String str when str.length() > 5 -> System.out.println(str.strip());
            //case "Sophie" -> System.out.println("My lovely daughter");
            default -> System.out.println("FALLBACK");
        }
    }
}
