package solutions.part6;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
sealed interface Figure {
}

record Point(int x, int y) implements Figure {
}

record Line(Point start,
            Point end) implements Figure {
}

record Triangle(Point pointA,
                Point pointB,
                Point PointC) implements Figure {
}