package b_slides;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class RecordJSONExampleTest {

	final ObjectMapper mapper = new ObjectMapper()
		      .enable(SerializationFeature.INDENT_OUTPUT);

	
	@Test
	void serializeRecord() throws Exception {
	    // Given
	    var person = new Person(
	            "Michael",
	            "Inden",
	            "Germany",
	            new Date(71,1,7),
	            List.of("Author", "Speaker")
	    );

	    var expectedJson = """
	            {
	              "first_name" : "Michael",
	              "last_name" : "Inden",
	              "address" : "Germany",
	              "birthday" : 34729200000,
	              "achievements" : [ "Author", "Speaker" ]
	            }""";

	    // When
	    var serialized = mapper.writeValueAsString(person);

	    // Then
	    assertThat(serialized).isEqualTo(expectedJson);
	}

	
	@Test
	void deserializeRecord() throws Exception {
		
	    // Given
	    var expectedPerson = new Person(
	            "Michael",
	            "Inden",
	            "Germany",
	            new Date(34729200000L),
	            List.of("Author", "Speaker")
	    );

	    var jsonInput = """
	            {
	              "first_name" : "Michael",
	              "last_name" : "Inden",
	              "address" : "Germany",
	              "birthday" : 34729200000,
	              "achievements" : [ "Author", "Speaker" ]
	            }""";

	    // When
	    var deserialized = mapper.readValue(jsonInput, Person.class);

	    // Then
	    assertThat(deserialized).isEqualTo(expectedPerson);
	}
}
