package b_slides;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die Neuerungen in Java 17 LTS und 18"
 * 
 * @author Michael Inden
 * 
 * Copyright 2021/2022 by Michael Inden 
 */
public class RecordBuilderLikeExample
{
    public static void main(String[] args) 
    {
		record SimplePerson(String name, int age, String city) 
		{			
			SimplePerson(String name)
			{
				this(name, 0, "");
			}
			
			SimplePerson(String name, int age)
			{
				this(name, age, "");
			}
			
			SimplePerson withAge(int newAge)
			{
				return new SimplePerson(name, newAge, city);
			}
			
			SimplePerson withCity(String newCity)
			{
				return new SimplePerson(name, age, newCity);
			}
		}
		
		SimplePerson mike = new SimplePerson("Mike", 51, "Zürich");
		SimplePerson mike2 = new SimplePerson("Mike", 35).withCity("Kiel");
		SimplePerson mike3 = new SimplePerson("Mike").withAge(42).withCity("Aachen");
		System.out.println(mike);
		System.out.println(mike2);
		System.out.println(mike3);
    }
}
