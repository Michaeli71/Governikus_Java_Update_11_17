package solutions.part2;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die Neuerungen in Java 17 LTS und 18"
 * 
 * @author Michael Inden
 * 
 * Copyright 2021/2022 by Michael Inden 
 */
public class Hello
{
    public static void main(String... args)
    {
	    System.out.println("Hello");
	    System.out.println("Hello JAX");
	    System.out.println("Hello");
    }
}