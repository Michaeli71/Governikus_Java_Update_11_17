package multireleaseexample;

import java.util.List;
import java.util.Collection;

public class Generator 
{
   public Collection<String> createStrings() 
   {
      return List.of("New", "JDK 9", "Collection", "Factory", "Methods");
   }
}
